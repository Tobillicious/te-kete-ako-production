var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var central_intelligence_exports = {};
__export(central_intelligence_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(central_intelligence_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY
);
async function handler(event, context) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }
  try {
    const { query, context: queryContext, options = {} } = JSON.parse(event.body || "{}");
    console.log(`\u{1F9E0} Central Intelligence Query: "${query}"`);
    const intelligence = await queryCollectiveIntelligence(query, queryContext, options);
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({
        success: true,
        query,
        intelligence,
        sources_consulted: intelligence.sources,
        confidence: intelligence.confidence,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      })
    };
  } catch (error) {
    console.error("\u{1F6A8} Central Intelligence Error:", error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({
        error: "Intelligence query failed",
        message: error.message
      })
    };
  }
}
async function queryCollectiveIntelligence(query, context, options) {
  const queryLower = query.toLowerCase();
  const sources = [];
  let primaryResponse = null;
  let confidence = 0;
  const graphRAGResults = await queryGraphRAG(query, options);
  sources.push("GraphRAG Knowledge Graph");
  const agentKnowledge = await queryAgentMemory(query);
  if (agentKnowledge.length > 0) {
    sources.push("Agent Institutional Memory");
  }
  if (queryLower.includes("popular") || queryLower.includes("most used") || queryLower.includes("trending")) {
    const analyticsInsights = await queryAnalytics(query);
    sources.push("Real-Time Analytics");
    primaryResponse = analyticsInsights;
    confidence = 0.9;
  }
  if (queryLower.includes("rating") || queryLower.includes("feedback") || queryLower.includes("teacher says")) {
    const feedbackInsights = await queryTeacherFeedback(query);
    sources.push("Teacher Feedback System");
    if (!primaryResponse) primaryResponse = feedbackInsights;
    confidence = Math.max(confidence, 0.85);
  }
  if (queryLower.includes("m\u0101ori") || queryLower.includes("cultural") || queryLower.includes("whakatauk\u012B")) {
    const culturalResults = await queryCulturalIntelligence(query);
    sources.push("Cultural Intelligence Layer");
    confidence = Math.max(confidence, 0.95);
  }
  if (!primaryResponse) {
    primaryResponse = graphRAGResults;
    confidence = graphRAGResults.resources.length > 0 ? 0.8 : 0.3;
  }
  const synthesized = await synthesizeIntelligence({
    graphRAG: graphRAGResults,
    agentMemory: agentKnowledge,
    primary: primaryResponse,
    query,
    context
  });
  return {
    ...synthesized,
    sources,
    confidence,
    collective_intelligence: true
  };
}
async function queryGraphRAG(query, options = {}) {
  const limit = options.limit || 10;
  const keywords = extractKeywords(query);
  const searchTerm = keywords[0] || query;
  const { data: resources, error } = await supabase.from("graphrag_resources").select("file_path, title, quality_score, year_level, subject, cultural_context, resource_type, content_preview").or(`title.ilike.%${searchTerm}%,content_preview.ilike.%${searchTerm}%,subject.ilike.%${searchTerm}%`).order("quality_score", { ascending: false }).limit(limit);
  if (error) {
    console.error("GraphRAG query error:", error);
    return { resources: [], relationships: [] };
  }
  const resourcePaths = (resources || []).slice(0, 5).map((r) => r.file_path);
  const { data: relationships } = await supabase.from("graphrag_relationships").select("source_path, target_path, relationship_type, confidence").in("source_path", resourcePaths).order("confidence", { ascending: false }).limit(20);
  return {
    resources: resources || [],
    relationships: relationships || [],
    total_in_knowledge_graph: 17363
  };
}
async function queryAgentMemory(query) {
  const keywords = extractKeywords(query);
  const { data, error } = await supabase.from("agent_knowledge").select("source_name, doc_type, key_insights, technical_details").or(`source_name.ilike.%${keywords[0]}%,key_insights::text.ilike.%${keywords[0]}%`).order("created_at", { ascending: false }).limit(5);
  return data || [];
}
async function queryAnalytics(query) {
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1e3).toISOString();
  const { data, error } = await supabase.from("component_analytics").select("clicked_resource_path, resource_path").eq("user_action", "click").gte("timestamp", sevenDaysAgo).not("clicked_resource_path", "is", null);
  const clickCounts = {};
  (data || []).forEach((item) => {
    clickCounts[item.clicked_resource_path] = (clickCounts[item.clicked_resource_path] || 0) + 1;
  });
  const topResources = Object.entries(clickCounts).sort((a, b) => b[1] - a[1]).slice(0, 10);
  return {
    type: "analytics_insights",
    top_clicked_resources: topResources,
    data_range: "Last 7 days"
  };
}
async function queryTeacherFeedback(query) {
  const { data, error } = await supabase.from("teacher_feedback").select("resource_path, rating, comment, feedback_type").order("rating", { ascending: false }).limit(10);
  const avgRating = data && data.length > 0 ? (data.reduce((sum, f) => sum + f.rating, 0) / data.length).toFixed(1) : null;
  return {
    type: "teacher_insights",
    average_rating: avgRating,
    recent_feedback: data || [],
    total_reviews: data?.length || 0
  };
}
async function queryCulturalIntelligence(query) {
  const { data, error } = await supabase.from("graphrag_resources").select("file_path, title, quality_score, year_level, subject").eq("cultural_context", true).gte("quality_score", 85).order("quality_score", { ascending: false }).limit(10);
  return {
    cultural_resources: data || [],
    total_cultural_resources: 7550,
    cultural_integration_rate: "43.5%",
    cultural_guardian_validation: "Active"
  };
}
async function synthesizeIntelligence({ graphRAG, agentMemory, primary, query, context }) {
  const synthesis = {
    query_interpretation: interpretQuery(query),
    resources_found: graphRAG.resources,
    total_resources_available: graphRAG.total_in_knowledge_graph,
    relationships_discovered: graphRAG.relationships,
    institutional_insights: agentMemory,
    recommendations: generateRecommendations(graphRAG, agentMemory),
    learning_paths: generateLearningPaths(graphRAG.resources, graphRAG.relationships),
    cultural_elements: extractCulturalElements(graphRAG.resources),
    quality_summary: calculateQualitySummary(graphRAG.resources)
  };
  return synthesis;
}
function interpretQuery(query) {
  const queryLower = query.toLowerCase();
  if (queryLower.includes("find") || queryLower.includes("search") || queryLower.includes("show")) {
    return { intent: "resource_discovery", action: "search" };
  }
  if (queryLower.includes("path") || queryLower.includes("sequence") || queryLower.includes("plan")) {
    return { intent: "learning_path", action: "generate_sequence" };
  }
  if (queryLower.includes("cultural") || queryLower.includes("m\u0101ori")) {
    return { intent: "cultural_integration", action: "find_cultural_resources" };
  }
  if (queryLower.includes("best") || queryLower.includes("top") || queryLower.includes("recommended")) {
    return { intent: "curation", action: "rank_by_quality" };
  }
  return { intent: "general_search", action: "broad_discovery" };
}
function generateRecommendations(graphRAG, agentMemory) {
  const recommendations = [];
  graphRAG.relationships.forEach((rel) => {
    recommendations.push({
      type: rel.relationship_type,
      confidence: rel.confidence,
      source: "GraphRAG relationship graph"
    });
  });
  agentMemory.forEach((memory) => {
    if (memory.key_insights) {
      recommendations.push({
        type: "institutional_knowledge",
        insight: memory.key_insights[0],
        source: "Agent institutional memory"
      });
    }
  });
  return recommendations.slice(0, 8);
}
function generateLearningPaths(resources, relationships) {
  const paths = [];
  resources.slice(0, 3).forEach((resource) => {
    const relatedSteps = relationships.filter((r) => r.source_path === resource.file_path).slice(0, 3);
    if (relatedSteps.length > 0) {
      paths.push({
        starting_resource: resource.title,
        next_steps: relatedSteps.map((r) => ({
          relationship: r.relationship_type,
          target: r.target_path
        }))
      });
    }
  });
  return paths;
}
function extractCulturalElements(resources) {
  const cultural = resources.filter((r) => r.cultural_context);
  return {
    total_cultural: cultural.length,
    percentage: (cultural.length / resources.length * 100).toFixed(1) + "%",
    examples: cultural.slice(0, 3).map((r) => r.title)
  };
}
function calculateQualitySummary(resources) {
  if (resources.length === 0) return null;
  const gold = resources.filter((r) => r.quality_score >= 90).length;
  const silver = resources.filter((r) => r.quality_score >= 80 && r.quality_score < 90).length;
  const avg = resources.reduce((sum, r) => sum + (r.quality_score || 0), 0) / resources.length;
  return {
    gold_standard: gold,
    silver_standard: silver,
    average_quality: avg.toFixed(1),
    total_reviewed: resources.length
  };
}
function extractKeywords(query) {
  const stopWords = ["find", "show", "get", "me", "the", "a", "an", "with", "for", "about", "on", "of", "in"];
  return query.toLowerCase().split(/\s+/).filter((word) => !stopWords.includes(word) && word.length > 2);
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
