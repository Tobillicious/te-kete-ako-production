var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var get_resources_exports = {};
__export(get_resources_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(get_resources_exports);
var import_supabase_js = require("@supabase/supabase-js");
const supabase = (0, import_supabase_js.createClient)(
  process.env.SUPABASE_URL || "https://nlgldaqtubrlcqddppbq.supabase.co",
  process.env.SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5sZ2xkYXF0dWJybGNxZGRwcGJxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjE4Nzg3MzcsImV4cCI6MjAzNzQ1NDczN30.j2p9UeHpHuGWnJ6rDv5XGq-AZI11-UXwFsKR3IHQT48"
  // Note: We use the ANON_KEY for public, read-only access, 
  // relying on Row Level Security (RLS) in the database.
);
const handler = async (event, context) => {
  const headers = {
    "Access-Control-Allow-Origin": process.env.SITE_URL || "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
    "Content-Type": "application/json"
  };
  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers };
  }
  if (event.httpMethod !== "GET") {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: "Method not allowed" })
    };
  }
  try {
    const { data, error } = await supabase.from("resources").select("title, description, type, path, subject, year_levels, tags, nz_curriculum_links").order("title", { ascending: true });
    if (error) {
      console.error("Error fetching resources:", error);
      throw error;
    }
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ success: true, resources: data })
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ success: false, message: "Internal server error while fetching resources." })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
